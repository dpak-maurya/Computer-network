#include<stdio.h> 
#include<fcntl.h> 
#include<stdlib.h>
int main() 
{ 
    
    int fd1 = open("foobar.txt", O_RDONLY); 
    //int fd2 = open("foobar.txt", O_RDONLY);
    char arr[100];  
    read(fd1, arr, 100); 
    //read(fd2, arr, 10); 
    int count=0;
    while(count<3){
    printf("%c",arr[count]);
    count++;
    }
    exit(0); 
} 

