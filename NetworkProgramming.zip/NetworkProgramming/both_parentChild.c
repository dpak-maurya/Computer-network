#include "header.h"
int main()
{
   int pp1[2],pp2[2];
   pipe(pp1);
   pipe(pp2);
   int c=fork();
   int fd;
   if(c>0){
	close(pp1[0]);
	close(pp2[1]);
	const char *buff="hello.txt";
	//printf("%ld\n",strlen(buff));
	write(pp1[1],buff,strlen(buff)+1);
	wait(NULL);
	char ch[100];
	read(pp2[0],ch,100);
	printf("%s",ch);
	}

   else{
	close(pp1[1]);
	close(pp2[0]);
	char buff[100];
	read(pp1[0],buff,100);
	fd=open(buff,O_RDONLY);
	char ch[100];
	read(fd,ch,100);
	printf("%ld\n",strlen(ch)+1);
	write(pp2[1],ch,strlen(ch)+1);
	exit(1);
	}
	string s="deepak";
	
	return 0;
  }
  
   			
