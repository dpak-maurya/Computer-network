#include"header.h"
#include<iostream>
using namespace std;

int main(){
	const char *p2="./p2";
    FILE* fd=popen(p2,"r");
    char buff[1024];
    fgets(buff,1024,fd);
    cout<<buff<<endl;
	return 0; 
}
