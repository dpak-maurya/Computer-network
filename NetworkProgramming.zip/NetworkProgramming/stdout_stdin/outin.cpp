#include"header.h"
#include<iostream>
using namespace std;

int  main(){
	int fd;
	fd=open("out_in.txt",O_WRONLY | O_TRUNC);
	if(fd>0)
	{
	   if(dup2(fd,1)>0)
	   {
	   		cout<<"hii this is from cout statement\n";
	   }
	  
    }
    fd=open("out_out.txt",O_RDWR | O_TRUNC);
    dup2(1,fd);
    cout<<"this  should  be in terminal\n";
    char buff[100];
    read(fd,buff,100);
   	//cout<<buff<<" "<<strlen(buff)<<endl;
    
        
	return 0;
}
