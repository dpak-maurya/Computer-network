#include "header.h"
#include<iostream>
using namespace std;
int main()
{
  //Process 2 std output to process 1 
	/*
	const char *p2="./p2";
    FILE* fd=popen(p2,"r");
    char buff[1024];
    fgets(buff,1024,fd);
    cout<<buff<<endl;
	return 0; 
	*/  
	
	//Process 1 std output to process2
	const char *p2="./p2";
	FILE* file=popen(p2,"w");
	//int fd=fdopen(file);
	//int fd=fileno(file);
	int fd=open("cout.txt",O_RDWR);
	dup2(fd,1);
	cout<<"this is from p1";
	return 0;
}
  
   			
