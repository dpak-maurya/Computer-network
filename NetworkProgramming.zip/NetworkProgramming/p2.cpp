#include"header.h"
#include<iostream>
using namespace std;

int main(int argc,char* argv[]){
	
	/*
	dup2(fd,1);
	cout<<"this is from p2\n";	
	exit(0);
	*/
	
	int fd=atoi(argv[1]);
	char buff[1024];
	int n=read(fd,buff,1024);
	buff[n]='\0';
	cout<<"this is p2\n";
	cout<<buff<<endl;
}
