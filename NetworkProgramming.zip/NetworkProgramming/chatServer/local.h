//
// Created by dpak on 08/01/20.
//

#ifndef CHATSERVER_LOCAL_H
#define CHATSERVER_LOCAL_H
const char ID='M';
const long SERVER=1L;
typedef struct{
    long msg_to;
    long msg_fm;
    char buffer[1024];
}MESSAGE;
#endif //CHATSERVER_LOCAL_H
