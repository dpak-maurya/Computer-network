#include "local.h"
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>


struct mbuf{
    long mtype;
    char mtext[100];
};

int main()
{
    key_t key;
    pid_t cli_pid;
    int mid,n;
    MESSAGE msg;
    static char m_key[10];
    cli_pid=getpid();
    printf("%d\n",getpid());
    mid=msgget(ftok(".",ID),IPC_CREAT|0666);
    int i=1;
    while (1){
        if(i==1)
        {
            sprintf(m_key,"%d",getpid());
            strcpy(msg.buffer,m_key);
            msg.msg_to=SERVER;
            msg.msg_fm=cli_pid;
            if(msgsnd(mid,&msg, sizeof(msg.buffer),IPC_NOWAIT)!=0)
            {
                printf("client: msg send\n");
                return 1;
            }
            i++;
        }
        fgets(msg.buffer,1000,stdin);
        msg.msg_to=SERVER;
        msg.msg_fm=cli_pid;


        if(msgsnd(mid,&msg, sizeof(msg.buffer),IPC_NOWAIT)!=0)
            printf("client: msg send\n");

        sleep(2);

        if(msgrcv(mid,&msg,1000,0,MSG_NOERROR)!=-1)
        {
            printf("%s",msg.buffer);
        }
    }
    return 0;
}