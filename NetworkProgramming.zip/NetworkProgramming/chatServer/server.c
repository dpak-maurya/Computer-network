#include "local.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>


int main(){
    int mid,n;
    MESSAGE msg;

    mid=msgget(ftok(".",ID),0666);
    msgctl(mid, IPC_RMID, NULL);
    mid=msgget(ftok(".",ID),IPC_CREAT|0666);

    long pidArray[10];
    int i=0;


    while(1) {

        if (msgrcv(mid, &msg, sizeof(msg.buffer), SERVER, MSG_NOERROR)== -1) {
            printf("Server: msgrcv\n");
            return 2;
        }
        if(msg.msg_fm==atoi(msg.buffer))
        {
            pidArray[i]=msg.msg_fm;
            i++;
            continue;
        }

        for(int j=0;j<i;j++)
        {
            if(pidArray[j]!=msg.msg_fm)
            {
                msg.msg_to = pidArray[j];
                msg.msg_fm = SERVER;
                printf("%d %s",pidArray[j],msg.buffer);
                if (msgsnd(mid, &msg, sizeof(msg.buffer), 0) !=0) {
                    printf("Server: msgsnd\n");
                    return 3;
                }
            }
        }


        sleep(1);

    }
    return 0;
}