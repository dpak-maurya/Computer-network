#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <netinet/in.h>


int main()
{
    int sfd1,sfd2,sfd3;
    struct sockaddr_in addr1,addr2,addr3;

    sfd1=socket(AF_INET,SOCK_STREAM,0);
    sfd2=socket(AF_INET,SOCK_STREAM,0);
    sfd3=socket(AF_INET,SOCK_STREAM,0);

    addr1.sin_family=AF_INET;
    addr1.sin_port=htons(8080);
    addr1.sin_addr.s_addr=INADDR_ANY;

    addr2.sin_family=AF_INET;
    addr2.sin_port=htons(8081);
    addr2.sin_addr.s_addr=INADDR_ANY;

    addr3.sin_family=AF_INET;
    addr3.sin_port=htons(8082);
    addr3.sin_addr.s_addr=INADDR_ANY;


}