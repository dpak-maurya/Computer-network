#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#define MAXLINE 1024
#define MAXLINE 1024
#define PORT1 8071
#define PORT2 8072
int max(int x, int y)
{
    if (x > y)
        return x;
    else
        return y;
}
int main(int argc, char const *argv[]) 
{
	int sfd[2],nsfd;
	struct sockaddr_in addr1,addr2;
	char buff[100];
	
	sfd[0]=socket(AF_INET,SOCK_STREAM,0);
	addr1.sin_family = AF_INET; 
    	addr1.sin_addr.s_addr = INADDR_ANY; 
    	addr1.sin_port = htons(PORT1); 

	bind(sfd[0], (struct sockaddr *)&addr1,sizeof(addr1));

	sfd[1]=socket(AF_INET,SOCK_STREAM,0);
	addr2.sin_family = AF_INET; 
    	addr2.sin_addr.s_addr = INADDR_ANY; 
    	addr2.sin_port = htons(PORT2); 

	bind(sfd[1], (struct sockaddr *)&addr2,sizeof(addr2));

	listen(sfd[0],10);
	listen(sfd[1],10);
	
	int listenfd, connfd, udpfd, nready, maxfdp1; 
    char buffer[MAXLINE]; 
    pid_t childpid; 
    fd_set rset; 
    ssize_t n; 
    socklen_t len; 
    const int on = 1;

    char* message = "Hello Client"; 
    void sig_chld(int); 

    FD_ZERO(&rset);

    maxfdp1 = max(listenfd, udpfd) + 1; 
    for (;;) { 

        FD_SET(listenfd, &rset); 
        FD_SET(udpfd, &rset); 

        nready = select(maxfdp1, &rset, NULL, NULL, NULL); 

        if (FD_ISSET(listenfd, &rset)) { 
            len = sizeof(cliaddr); 
            connfd = accept(listenfd, (struct sockaddr*)&cliaddr, &len); 
            if ((childpid = fork()) == 0) { 
                close(listenfd); 
                bzero(buffer, sizeof(buffer)); 
                printf("Message From TCP client: "); 
                read(connfd, buffer, sizeof(buffer)); 
                puts(buffer); 
                write(connfd, (const char*)message, sizeof(buffer)); 
                close(connfd); 
                exit(0); 
            } 
            close(connfd); 
        } 
        // if udp socket is readable receive the message. 
        if (FD_ISSET(udpfd, &rset)) { 
            len = sizeof(cliaddr); 
            bzero(buffer, sizeof(buffer)); 
            printf("\nMessage from UDP client: "); 
            n = recvfrom(udpfd, buffer, sizeof(buffer), 0, 
                         (struct sockaddr*)&cliaddr, &len); 
            puts(buffer); 
            sendto(udpfd, (const char*)message, sizeof(buffer), 0, 
                   (struct sockaddr*)&cliaddr, sizeof(cliaddr)); 
        } 
    } 
} 
	
	
	/*
	struct pollfd pol[2];	
	for(int i=0;i<2;i++)
	{
		pol[i].fd=sfd[i];
		pol[i].events=POLLIN;
		pol[i].revents=0;
	}	
	
	while(1)
	{
		poll(pol,10,1000);
		
			if(pol[0].revents & POLLIN)
			{
				nsfd=accept(pol[0].fd, (struct sockaddr *)&addr1,&addrlen1)	;
				printf("client added to s1\n");
				int c=fork();
				if(c>0)
				{
					close(nsfd);
				}
				else if(c==0)
				{
					dup2(nsfd,1);
					dup2(nsfd,0);
					
					execlp("./s1","s1",NULL);
					
				}
			}
	
			if(pol[1].revents & POLLIN)
			{
				nsfd=accept(pol[1].fd, (struct sockaddr *)&addr2,&addrlen2)	;
				printf("client added to s2\n");
				int c=fork();
				if(c>0)
				{
					close(nsfd);
				}
				else if(c==0)
				{
					dup2(nsfd,1);
					dup2(nsfd,0);
					
					execlp("./s2","s2",NULL);
				}
			}
		
	}*/
	
	



	
}
