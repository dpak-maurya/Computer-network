#include <unistd.h> 
#include <stdio.h> 
#include <sys/socket.h> 
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h>
#include<pthread.h>
int main()
{
	char buff[10];
	buff[0]='\0';
	int c=0;
	//printf("in s1\n");
	while(1)
	{
		//strcpy(buff,"");
		read(0,buff,10);
		//buff[n]='\0';
		buff[strlen(buff)-1]='\0';
		strcat(buff,"$");
		//buff[strlen(buff)]='\n';	
		write(1,buff,strlen(buff));
		memset(buff,0,strlen(buff));
		//fflush(stdout);	
	}
}
