#include <unistd.h> 
#include <stdio.h> 
#include <sys/socket.h> 
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h>
#include<pthread.h>
#include<sys/poll.h>
#define PORT1 8071
#define PORT2 8072
int PORT;
int sfd;
int main(int argc, char const *argv[]) 
{

	if(!strcmp(argv[1],"1"))
	PORT=PORT1;
	else
	PORT=PORT2;


//	printf("%d",PORT);		
	struct sockaddr_in addr;
	char buff[10];
	sfd=socket(AF_INET,SOCK_STREAM,0);
	addr.sin_family = AF_INET; 
	addr.sin_port = htons(PORT);
	//addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK);

	if(inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr)<=0) 
	{ 
		printf("\nInvalid address/ Address not supported \n"); 
		return -1; 
	}



	connect(sfd, (struct sockaddr *)&addr, sizeof(addr));

	struct pollfd pol[2];


	pol[0].fd=0;
	pol[1].fd=sfd;
	for(int i=0;i<2;i++)
	{
		pol[i].events=POLLIN;
		pol[i].revents=0;
	}
	
	char buff1[10],ch;
	while(1)
	{
		poll(pol,2,1000);
		if(pol[0].revents &POLLIN)
		{
			read(0,buff,10);
			send(sfd,buff,strlen(buff),0);			

		}
		if(pol[1].revents &POLLIN)
		{
			read(sfd,buff1,10);
			write(1,buff1,strlen(buff1));			

		}
		memset(buff,0,sizeof(buff));
		memset(buff1,0,sizeof(buff1));
		
	}
	

}
