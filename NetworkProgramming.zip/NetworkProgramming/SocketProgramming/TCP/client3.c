#include<stdio.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<string.h>
#include<netdb.h>
#include<poll.h>
#include<netinet/in.h> 
#define PORT 8080

int main(int argc,char* argv[])
{
	int sock=0,valread;
	struct sockaddr_in serv_addr;
	//struct hostent *ptrh;
	char buffer[1024]={0};
	if((sock=socket(AF_INET,SOCK_STREAM,0))<0)
	{
		printf("socket creation error\n");
		return -1;
	}
	//ptrh=gethostbyname("172.30.231.210");
     //	memcpy(&serv_addr.sin_addr,ptrh->h_addr,ptrh->h_length);
	serv_addr.sin_family=AF_INET;
	serv_addr.sin_port=htons(PORT);
	if(connect(sock,&serv_addr,sizeof(serv_addr))<0)
	{
		printf("\nconnection failed\n");
		return -1;
	}
	struct pollfd fds[2];
	fds[0].fd=0;
	fds[1].fd=sock;
	fds[0].events=0;
	fds[0].events=0;
	fds[0].events|=POLLIN;
	fds[1].events=0;
	fds[1].events|=POLLIN;
	while(1)
	{
		poll(fds,2,5000);
		if(fds[0].revents&POLLIN)
		{
			char ch[100];
			fgets(ch,100,stdin);
			send(sock,ch,100,0);
		}
		if(fds[1].revents&POLLIN)
		{
			char buf[100];
			recv(sock,buf,100,0);
			printf("%s\n",buf);
		}
	}
}
