#include<unistd.h>
#include<stdio.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<poll.h>
#include<netinet/in.h>
#include<string.h>
#define PORT 8080
int main(int argc,char const *argv[])
{
	int server_fd, new_socket,valread;
	struct sockaddr_in address;
	int addrlen = sizeof(address);
	char buffer[1024];
	if((server_fd=socket(AF_INET,SOCK_STREAM,0))==0)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}
	address.sin_family=AF_INET;
	address.sin_addr.s_addr=INADDR_ANY;
	address.sin_port=htons(PORT);
	if(bind(server_fd,&address,sizeof(address))<0)
	{
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
	if(listen(server_fd,3)<0)
	{
		perror("listen failed");
		exit(EXIT_FAILURE);
	}
	if((new_socket=accept(server_fd,&address,&addrlen))<0)
	{
		perror("accept");
		exit(EXIT_FAILURE);
	}
	struct pollfd fds[2];
	fds[0].fd=0;
	fds[1].fd=new_socket;
	fds[0].events=0;
	fds[0].events|=POLLIN;
	fds[1].events=0;
	fds[1].events|=POLLIN;
	while(1)
	{
		poll(fds,2,5000);
		if(fds[0].revents&POLLIN)
		{
			char ch[100];
			fgets(ch,100,stdin);
			send(new_socket,ch,100,0);
		}
		if(fds[1].revents&POLLIN)
		{
			char buf[100];
			recv(new_socket,buf,100,0);
			printf("%s\n",buf);
		}
	}
	return 0;
}








