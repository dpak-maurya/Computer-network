#include<unistd.h>
#include<stdio.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<poll.h>
#include<netinet/in.h>
#include<string.h>
#define PORT 8080
int main(int argc,char const *argv[])
{
	int opt=1;
	int server_fd, new_socket,valread;
	struct sockaddr_in address;
	int addrlen = sizeof(address);
	char buffer[1024];
	if((server_fd=socket(AF_INET,SOCK_STREAM,0))==0)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}
	address.sin_family=AF_INET;
	address.sin_addr.s_addr=INADDR_ANY;
	address.sin_port=htons(PORT);
	setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));
	if(bind(server_fd,&address,sizeof(address))<0)
	{
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

	if(listen(server_fd,3)<0)
	{
		perror("listen failed");
		exit(EXIT_FAILURE);
	}
	int arr[100];
	int count=0;
	
	struct pollfd fds[10];
	for(int i=0;i<10;i++)
	{
		//fds.fd[i]=0;
		fds[i].events=0;
		fds[i].revents=0;
	}
	fds[0].fd=server_fd;
	fds[0].events|=POLLIN;
	int nsfd;
	count=1;
	write(1,"started\n",8);
   while(1)
   {
   	int t=poll(fds,count,5000);
   	if(t==0)
   	{
   		write(1,"TIMEOUT\n",8);
   	}
   	else
   	{
   		for(int i=0;i<count;i++)
   		{
   			if(i==0 && fds[i].revents&POLLIN)
   			{
   				if((nsfd=accept(fds[0].fd,&address,&addrlen))<0)
				{
					perror("accept");
					//exit(EXIT_FAILURE);
				}
				else
				{
					fds[count].fd=nsfd;
					fds[count].events|=POLLIN;
					count++;
					printf("Client added successfully\n");
				}
   			}
   			if(fds[i].revents&POLLIN)
   			{
   				char buf[100];
				recv(fds[i].fd,buf,100,0);
				printf("%s\n",buf);
				for(int j=1;j<count;j++)
				{
					if(i!=j)
					{
						send(fds[j].fd,buf,100,0);
					}
				}
   			}
   		}
   	   }
	}
	}/*
	arr[count++]=new_socket;
	for(int i=0;i<count;i++)
	{
		fds[i].fd=arr[i];
		fds[i].events=0;
		fds[i].events|=POLLIN;
	}
	for(int i=0;i<count;i++)
	{
		p
		if(fds[i].revents&POLLIN)
		{	
			char buf[100];
			recv(new_socket,buf,100,0);
			printf("%s\n",buf);
			for(int j=0;j<count;j++)
			{
				if(i!=j)
				{
					send(arr[j],buf,100,0);
				}
			}
		}
		
	}
   }	
}
	/*printf("request recived\n");
	while(1)
	{
		char buf[100];
		recv(new_socket,buf,100,0);
		printf("%s\n",buf);
	}
	for(int i=0;i<c;i++)
	{
		
		send(new_socket,ch,100,0);
	}
		while(1)
		{
			poll(fds,2,5000);
			if(fds[0].revents&POLLIN)
			{
				char ch[100];
				fgets(ch,100,stdin);
				send(new_socket,ch,100,0);
			}
			if(fds[1].revents&POLLIN)
			{
				char buf[100];
				recv(new_socket,buf,100,0);
				printf("%s\n",buf);
			}
		}
	}
}
return 0;
}*/
