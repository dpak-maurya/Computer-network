#include<stdio.h>
#include <stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<unistd.h>

int main()
{
	char msg[256]="you have a missed call from server\n";
	
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);

	struct sockaddr_in addr;
	addr.sin_family=AF_INET;
	addr.sin_port=htons(7215);
	addr.sin_addr.s_addr=INADDR_ANY;

	int addrlen= sizeof(addr);

	bind(sfd,(struct sockaddr*)&addr, sizeof(addr));

	listen(sfd,5);

	int nsfd;
	nsfd=accept(sfd,NULL,NULL);
	accept(sfd,&addr, &addrlen);

	send(nsfd,msg, sizeof(msg),0);
	close(sfd);
	return 0;
}