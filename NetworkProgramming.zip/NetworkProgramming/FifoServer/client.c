#include <signal.h>
#include <string.h>
#include "fifo_seqnum.h"

char clientFifo[CLIENT_FIFO_NAME_LEN];
 void removeFifo(void)
{
    unlink(clientFifo);
}
int
main(int argc, char *argv[]) {
    int serverFd, clientFd;

    struct request req;
    struct response resp;
    if (argc > 1 && strcmp(argv[1], "--help") == 0)

//    snprintf(clientFifo, CLIENT_FIFO_NAME_LEN, CLIENT_FIFO_TEMPLATE,
//             (long) getpid());
    sprintf(clientFifo,CLIENT_FIFO_TEMPLATE,getpid());
    printf("%s clientpid\n",clientFifo);
    if (mkfifo(clientFifo, 0666) == -1
        && errno != EEXIST)
        perror("mkfifo");
    if (atexit(removeFifo) != 0)
        perror("atexit");
    req.pid = getpid();
    req.seqLen = (argc > 1) ? atoi(argv[1]) : 1;
    serverFd = open(SERVER_FIFO, O_WRONLY);
    if (serverFd == -1)
        perror("server fifo");
    if (write(serverFd, &req, sizeof(struct request)) !=
       sizeof(struct request))
        perror("Can't write to server");
    clientFd = open(clientFifo, O_RDONLY);
    if (clientFd == -1)
        perror("can't read response from server");
    printf("%d\n", resp.seqNum);
    exit(EXIT_SUCCESS);
}