#include"header.h"
#include<iostream>
using namespace std;

int main(int argc,char* argv[]){
	
	int fd=atoi(argv[1]);
	char buff[500];
	int n=read(fd,buff,500);
	buff[n]='\0';
	cout<<"this is from p2\n";
	cout<<"p1 message: "<<buff;
	
	exit(0);
}
