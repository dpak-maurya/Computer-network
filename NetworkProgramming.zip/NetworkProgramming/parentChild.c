#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<string.h>

int main(){
  int fd[2];
   int c=0;
   pipe(fd);
   c=fork();
   //Parent process
   if(c>0){
   close(fd[0]);
   const char *msg="Parent to Child";
   write(fd[1],msg,strlen(msg)+1);
   exit(1);
   }
   //child process
   else{
   close(fd[1]);
   char buff[100];
   read(fd[0],buff,100);
    printf("%s\n",buff);
   exit(1);
}
return 0;
}
