#include  "header.h"
#include<iostream>
using namespace std;

int main(int argc,char** argv){
	int fd;
	if(argc==2)
	fd=open(argv[1],O_RDWR | O_CREAT | O_TRUNC,S_IRWXG);
	//change permission using chmod g+w filename
	else
	fd=open("foobar.txt",O_RDWR | O_TRUNC);
	
	if(fd>0)
	{
	   if(dup2(fd,1)>0)
	   {
	   		cout<<"hii this is from cout statement\n";
	   }
	   else
	   {
	   	cout<<"there is error for assigning fd to stdoutput\n";
	   }
    }
    else{
    cout<<"error in openning the file\n";
    }
    
    return 0;
}
     
