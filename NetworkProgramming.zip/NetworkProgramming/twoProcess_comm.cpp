#include "header.h"
#include<iostream>
using namespace std;
int main()
{
   int pp1[2],pp2[2];
   pipe(pp1);
   pipe(pp2);
   int c=fork();
   int fd;
   if(c>0){
   			close(pp1[0]);
   			close(pp2[1]);
   			cout<<"this is befor dup2\n";
   			dup2(pp1[1],1);
   			cout<<"this is the parent process";
   			
   			exit(0);
   		}	
   			
   			
   else{
   		
   			cout<<"this is the child process\n";
   		    //char buff[100];
   			//read(pp1[0],buff,100);
   			//cout<<buff<<" "<<strlen(buff)<<endl;
   			dup2(pp1[0],0);
   			const char* p2="./newchild";
	        execv(p2,NULL);		
   		}
   		return 0;
  }
  
   			
