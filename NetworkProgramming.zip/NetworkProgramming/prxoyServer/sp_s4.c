#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<signal.h>
#include<sys/socket.h>
#include<sys/select.h>
#include<sys/time.h>
#include<sys/shm.h>
#include<sys/ipc.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<netdb.h>
#include<pthread.h>
#define port 8084
int main()
{
    int sfd;
    struct sockaddr_in serv_addr;
    socklen_t addlen=sizeof(serv_addr);
    sfd = socket(AF_INET, SOCK_STREAM, 0);
    serv_addr.sin_family = AF_INET; 
    serv_addr.sin_port = htons(port);
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);
    connect(sfd,(struct sockaddr *)&serv_addr,addlen);
    printf("connected\n");
    
    
    struct sockaddr_in getaddr;
    socklen_t len=sizeof(getaddr);
    getsockname(sfd,(struct sockaddr*)&getaddr,&len);
    char myip[16];
    unsigned int myport;
    inet_ntop(AF_INET,&getaddr.sin_addr,myip,sizeof(myip));
    myport=ntohs(getaddr.sin_port);
    printf("local ip is %s\nlocal port is %d\n",myip,myport);
    
    struct sockaddr_in saddr;
    len=sizeof(saddr);
    getpeername(sfd,(struct sockaddr*)&saddr,&len);
    printf("foreign ip is %s\n",inet_ntoa(saddr.sin_addr));
    printf("foreign port is %d\n",ntohs(saddr.sin_port)); 
    
    fd_set rfds;
    FD_ZERO(&rfds);
    struct timeval t;
    t.tv_sec=50;
    t.tv_usec=0;
    int c;
    while(1)
    {
    		FD_SET(0,&rfds);
    		FD_SET(sfd,&rfds);
	        int pret=select(sfd+1,&rfds,NULL,NULL,&t);		
		if(pret>0){
		if(FD_ISSET(0,&rfds))
		{
			char ch[100];			
			fgets(ch,100,stdin);
			send(sfd,ch,strlen(ch)+1,0);
		}
		if(FD_ISSET(sfd,&rfds))
		{
			char buf[100];
			recv(sfd,buf,100,0);
			printf("%s\n",buf);
			send(sfd,buf,strlen(buf)+1,0);
		}}
		FD_ZERO(&rfds);
    }
}
   
   
