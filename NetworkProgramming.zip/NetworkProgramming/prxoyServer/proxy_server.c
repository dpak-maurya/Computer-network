#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<signal.h>
#include<sys/socket.h>
#include<sys/select.h>
#include<sys/time.h>
#include<sys/shm.h>
#include<sys/ipc.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<netdb.h>
#include<pthread.h>
#include<poll.h>
#include<semaphore.h>
#define port 9090
#define sp_port 8081
int sp_nsfd[5];
int sp[5][2]={0};
int nsfds[2]={0};
int cnt=0;
void cleanup(int signo)
{
	printf("Cleaning up sockets...\n");
	
	for(int i=0;i<2;i++)
	{
        	shutdown(nsfds[i], SHUT_RDWR);	//disallow further reads & writes
       		 close(nsfds[i]);
       	}
	for (int i = 0; i < 3; i++) {
		shutdown(sp_nsfd[i], SHUT_RDWR);	//disallow further reads & writes
		close(sp_nsfd[i]);
	}
	printf("Cleaned sockets!\n");
	exit(0);
}
void* proxy_special_server(void* arg)
{
	int s=*((int*)arg);
	fd_set rfds;
        while(1)
        {
        	printf("in thread %d\n",s+1);
        	FD_ZERO(&rfds);
       		 struct timeval t;
       		 t.tv_sec=10;
       		 t.tv_usec=0;
        	int mx=0;
        	for(int i=0;i<2;i++)
        	{
        		if(sp[s][i]==1)
        		{
        			FD_SET(nsfds[i],&rfds);
        			mx=(mx>nsfds[i])?mx:nsfds[i];
        		}
        	}
        	int pret=select(mx+1,&rfds,NULL,NULL,&t);
        	if(pret>0)
        	{
        		for(int i=0;i<2;i++)
        		{
				if(sp[s][i]==1)
				{
					if(FD_ISSET(nsfds[i],&rfds))
					{
						char ch[100];
       						recv(nsfds[i],ch,100,0);
       						send(sp_nsfd[s],ch,strlen(ch)+1,0);
       						recv(sp_nsfd[s],ch,100,0);
       						send(nsfds[i],ch,strlen(ch)+1,0);
       					}
       				}
       			}
       		}
       		
       		
       	}
}
 
void * acceptor(void* arg)
{
    int sfd, nsfd; 
    struct sockaddr_in address; 
    int opt = 1; 
    socklen_t addrlen = sizeof(address); 

    sfd = socket(AF_INET, SOCK_STREAM, 0);
       
    // Forcefully attaching socket to the port 8080 
    setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR|SO_REUSEPORT, &opt, sizeof(opt));
    
    address.sin_family = AF_INET; 
    address.sin_addr.s_addr = INADDR_ANY; 
    address.sin_port = htons( port ); 
       
    bind(sfd, (struct sockaddr *)&address,addrlen); 
    listen(sfd, 3);
    
    while(1)
    {
	//fcntl(sfd,F_SETFL,fcntl(sfd,F_GETFL,0)| O_NONBLOCK);
    	nsfd = accept(sfd, (struct sockaddr *)&address,&addrlen);
	if(nsfd>=0){
    	printf("REQUEST ACCEPTED\n");
	nsfds[cnt++]=nsfd;
	char ch[100];
        recv(nsfd,ch,100,0);
	printf("from client %d special server :%s\n",cnt,ch);
	int x;
	sscanf(ch,"%d",&x);
	sp[x-1][cnt-1]=1;
        }
    }    
} 	
int main(int argc,char const *argv[])
{
	signal(SIGINT,cleanup);//clean sockets after termination
    //accept connection of all special servers
    for(int i=0;i<5;i++)
    {
	int sp_sfd,opt=1;
    	struct sockaddr_in serv_addr;
    	socklen_t addlen=sizeof(serv_addr);
    	sp_sfd = socket(AF_INET, SOCK_STREAM, 0);
   	serv_addr.sin_family = AF_INET; 
    	serv_addr.sin_port = htons(sp_port+i);
    	serv_addr.sin_addr.s_addr=INADDR_ANY;
    	setsockopt(sp_sfd,SOL_SOCKET,SO_REUSEPORT|SO_REUSEADDR,&opt,sizeof(opt));
   	bind(sp_sfd,(struct sockaddr*)&serv_addr,addlen);
   	listen(sp_sfd,3);
    	int nsfd=accept(sp_sfd,(struct sockaddr *)&serv_addr,&addlen);
    	sp_nsfd[i]=nsfd;
    }
        pthread_t th[5],tid;
        pthread_create(&tid,NULL,&acceptor,NULL);
        for(int i=0;i<5;i++)
        {
		int* arg=malloc(sizeof(*arg));
		*arg=i;
		pthread_create(&th[i],NULL,&proxy_special_server,arg);	
	}
	pthread_join(tid,NULL);
	for(int i=0;i<5;i++)
	{
		pthread_join(th[i],NULL);
	}


   
}

