#include<iostream>
#include<string.h>
#include "header.h"
using namespace std;

int main(){
	int c=0;
	cout<<"This is the test"<<endl;
	c=fork();
	if(c>0){
	cout<<"this is the parent process\n";
	wait(NULL);
	cout<<"this is after child process---parent\n";
	}
	else{
	cout<<"this is the child proces\n";
	
    char* args[]={"./childProgram",NULL};
	execv(args[0],args);
	cout<<"this is after calling the exec from child process\n";
	}
}

