#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <sys/msg.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>

#define PORT 8000
struct mesg_buffer {
    long mesg_type;
    char mesg_text[100];
} message;
void hdfn() {
    printf("hii this\n");
}
int main(int argc, char const *argv[])
{
    int sfd = 0;
    struct sockaddr_in serv_addr;
    if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Socket creation error \n");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr=inet_addr("127.0.01");

    if (connect(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
        printf("\nConnection Failed \n");
        return -1;
    }

    key_t key;
    int msgid;
    key = ftok("progfile", 65);
    msgid = msgget(key, 0666 | IPC_CREAT);

    while(1){
        char str1[100]={0};

        fgets(str1, 80, stdin);
        send(sfd , str1 , strlen(str1) , 0 );

        char str2[100]={0};
        recv(sfd , str2, 1024, 0);
        printf("server: %s",str2);

        msgrcv(msgid, &message, sizeof(message), 1, 0);
        printf("continue (y/n) :");
        char ch;
        scanf("%c",ch);
        fflush(stdin);
        if(message.mesg_text!=NULL && ch=='n')
        {
            printf("Data Received is : %s \n",message.mesg_text);
            kill(atoi(message.mesg_text),SIGUSR1);
            break;
        }
    }
    char * myfifo = "/tmp/myfifo";
    mkfifo(myfifo, 0666);
    int fd1;

    while(1){
    char str1[100]={0};
    fd1 = open(myfifo,O_RDONLY);
    read(fd1, str1, 80);
    send(sfd , str1 , strlen(str1) , 0 );
    close(fd1);
    char str2[100]={0};
    fd1 = open(myfifo,O_WRONLY);
    recv(sfd , str2, 1024, 0);
    write(fd1, str2, strlen(str2)+1);
    close(fd1);
}
    msgctl(msgid, IPC_RMID, NULL);
   // close(cfd);

    return 0;
}