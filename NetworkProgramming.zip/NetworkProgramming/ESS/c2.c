#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <sys/msg.h>
#include <sys/signal.h>
#include <wait.h>
#include <sys/stat.h>
#include <fcntl.h>

#define PORT 8000

struct mesg_buffer {
    long mesg_type;
    char mesg_text[100];
} message;

void hdfn(){
printf("client1 has send the permission\n");
    int fd;
    char * myfifo = "/tmp/myfifo";
    mkfifo(myfifo, 0666);

    while(1) {
        char arr1[80], arr2[80];
        fd = open(myfifo, O_WRONLY);
        //printf("client: ");
        fgets(arr2, 80, stdin);
        write(fd, arr2, strlen(arr2)+1);
        close(fd);

        fd = open(myfifo, O_RDONLY);
        read(fd, arr1, sizeof(arr1));
        printf("server: %s\n", arr1);
        close(fd);}
}

int main()
{
    signal(SIGUSR1,hdfn);
    key_t key;
    int msgid;
    key = ftok("progfile", 65);
    msgid = msgget(key, 0666 | IPC_CREAT);
    message.mesg_type = 1;
    sprintf(message.mesg_text,"%d",getpid());
    //sleep(10);
    msgsnd(msgid, &message, sizeof(message), 0);

    printf("Data send is : %s \n", message.mesg_text);
    while (1);
    return 0;
}