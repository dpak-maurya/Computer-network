#include "header.h"
#include<iostream>
using  namespace std;

int main(){
   cout<<"this program is called by child program\n";
   return 0;
   }
