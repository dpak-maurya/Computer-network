#include<stdlib.h>
#include<stdio.h>

int main(){
	char *msg="hello";
	printf("%ld",sizeof(*msg)/sizeof(char));
	return  0;
}
