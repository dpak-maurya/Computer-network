#include"header.h"
#include<iostream>
#include<string.h>
using namespace std;

int main(){
	
	int pp[2];
	pipe(pp);	
	int c=fork();
	
	if(c>0){
	close(pp[1]);
	char buff[100];
	read(pp[0],buff,100);
	cout<<buff<<endl;
	}
	else{
	close(pp[0]);
	char *msg="this is the message from child to parent";
	
	write(pp[1],msg,strlen(msg)+1);
	exit(1);
	}
}
	
	
	
	
