#include "header.h"
#include "local.h"
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/poll.h>

int main(){

    int fd;
    char * myfifo[] = {"Sfo1","Sfo2"};

//    for(int i=0;i<2;i++)
//    mkfifo(myfifo[i], 0666);
    mkfifo("Sfo1",0666);

 //   struct pollfd fds[2];

//    for(int i=0;i<2;i++)
//    {
//        fds[i].events=POLL_IN;
//        fds[i].fd=open(myfifo[i],O_RDONLY);
//    }
//    while (1) {
//        poll(fds, 2, 2000);
//        for (int i = 0; i < 2; i++) {

  //          if (fds[i].revents && POLL_IN) {
            int msgno[20];
            for(int i=0;i<20;i++)
            {
                msgno[i]=0;
            }

             fd=open("Sfo1",O_RDONLY);
            char arr2[100];
            int r = read(fd, arr2, 100);
            arr2[r] = '\0';
            if(msgno[arr2[0]-'0']==0)
            {
                write(1, arr2, strlen(arr2) + 1);
            close(fd);
            msgno[arr2[0]-'0']=1;
            }

            fd=open("Sfo2",O_RDONLY);
            char arr1[100];
            int r1 = read(fd, arr1, 100);
            arr1[r1] = '\0';

            if(msgno[arr1[0]-'0']==0)
            {
                write(1, arr2, strlen(arr2) + 1);
                close(fd);
                msgno[arr1[0]-'0']=1;
            }
   //         }
     //   }
    //}

    return 0;
}