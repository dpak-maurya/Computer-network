//
// Created by dpak on 08/01/20.
//

#ifndef CHATSERVER_LOCAL_H
#define CHATSERVER_LOCAL_H
const char ID='M';
const char SHM_KEY ='S';
const long SERVER=1L;
const long EDITOR=5L;
const long WRITER=4L;

typedef struct{
    long msg_to;
    long msg_fm;
    char buffer[1024];
}MESSAGE;

typedef struct  {
    int cntr;
    int write_complete;
    int read_complete;
}SHMMSG;
#endif //CHATSERVER_LOCAL_H
