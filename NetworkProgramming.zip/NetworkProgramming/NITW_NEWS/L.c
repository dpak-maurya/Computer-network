#include <sys/shm.h>
#include "local.h"
#include "header.h"


int main(int argc,char** argv)
{
   printf("%s",argv[0]);

    return 0;
}