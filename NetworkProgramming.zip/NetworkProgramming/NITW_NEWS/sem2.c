#include <stdlib.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include
#include
#include
#include
#include
#include
<sys/types.h>
<sys/stat.h>
<sys/sem.h>
<sys/shm.h>
"binary_sems.h"
"tlpi_hdr.h"
#define SHM_KEY 0x1234
#define SEM_KEY 0x5678
#define WRITE_SEM 0
#define READ_SEM 1
#ifndef BUF_SIZE
#define BUF_SIZE 1024
#endif /* Allow "cc -D" to override definition */
struct shmseg {
    int cnt;
    char buf[BUF_SIZE];
};

int main(int argc, char *argv[])
{
    int semid, shmid, bytes, xfrs;
    struct shmseg *shmp;
    union semun dummy;

    semid = semget(SEM_KEY, 2, IPC_CREAT | 0666);

    shmid = shmget(SHM_KEY, sizeof(struct shmseg), IPC_CREAT | 0666);
    shmp = shmat(shmid, NULL, 0);
    if (shmp == (void *) -1)
        printf("error");

    for (xfrs = 0, bytes = 0; ; xfrs++, bytes += shmp->cnt) {
        if (reserveSem(semid, WRITE_SEM) == -1)
            shmp->cnt = read(STDIN_FILENO, shmp->buf, BUF_SIZE);
        if (shmp->cnt == -1)
            errExit("read");
        if (releaseSem(semid, READ_SEM) == -1)
        if (shmp->cnt == 0)
            break;
    }
/* Wait until reader has let us have one more turn. We then know
reader has finished, and so we can delete the IPC objects. */
    i if (reserveSem(semid, WRITE_SEM) == -1)
        errExit("reserveSem");
    o if (semctl(semid, 0, IPC_RMID, dummy) == -1)
        errExit("semctl");
    if (shmdt(shmp) == -1)
        errExit("shmdt");
    if (shmctl(shmid, IPC_RMID, 0) == -1)
        errExit("shmctl");
    fprintf(stderr, "Sent %d bytes (%d xfrs)\n", bytes, xfrs);
    exit(EXIT_SUCCESS);
}