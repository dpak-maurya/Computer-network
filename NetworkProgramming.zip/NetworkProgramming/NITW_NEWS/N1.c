#include <sys/shm.h>
#include "local.h"
#include "header.h"

int main()
{
//    int fd;
//    char * myfifo = "n1fo";
//    mkfifo(myfifo, 0666);
//
//    char arr2[100];
//    fd = open(myfifo, O_WRONLY);
//    sprintf(arr2,"%d",getpid());
//
//    write(fd, arr2, strlen(arr2)+1);
//    close(fd);
//    if( access( "Sfo1", F_OK ) != -1 ) {
//        system("rm Sfo1");
//    }
    printf("%d\n",getpid());

    while (1) {
        sleep(10);
        char str[100];
        str[0]='\0';
        key_t key = ftok("shmfile",SHM_KEY);
        int shmid = shmget(key,1024,0666);
        char *str2 = (char *) shmat(shmid, (void *) 0, 0);

        printf("Data read from memory: %s", str2);
        strcpy(str, str2);
        shmdt(str2);

        printf("after N1\n");
        int pt = 0;

        char pid[10], pd;

        while (pt < strlen(str)) {
            if (str[pt] == ' ') {
                pid[pt] = '\0';
                break;
            }
            pid[pt] = str[pt];
            pt++;
        }
        if (atoi(pid) == getpid()) {
            //TODO
//            int c=fork();
//            if(c==0)
//            {
//                char args[]={str,NULL};
//                execv("./L",args);
//            }
        }
        printf("%d",pt);
        if (pt == 1) {
            int fd;
            mkfifo("Sfo1", 0666);
            fd = open("Sfo1", O_WRONLY);
            int wr = write(fd, str, strlen(str) + 1);
            if (wr == -1)
                printf("write error\n");
            close(fd);
        }
    }
    //shmctl(shmid,IPC_RMID,NULL);

    return 0;
}