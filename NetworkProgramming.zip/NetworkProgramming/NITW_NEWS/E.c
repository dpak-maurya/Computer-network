#include <sys/shm.h>
#include "local.h"
#include "header.h"
int N1=0;
int N2=0;
void readerPid(){

    int fd1;
    char * myfifo = "n1fo";
    mkfifo(myfifo, 0666);
    char str1[100];

    fd1 = open(myfifo,O_RDONLY);
    read(fd1, str1, 100);
    close(fd1);
    N1=atoi(str1);

    int fd2;
    char * myfifo2 = "n2fo";
    mkfifo(myfifo, 0666);
    char str2[100];

    fd2 = open(myfifo2,O_RDONLY);
    read(fd2, str2, 100);
    close(fd2);
    N2=atoi(str2);

    printf("%s %d %s %d",str1,N1,str2,N2);
    return;
}
int main(){

    //readerPid();
    sleep(1);
    int mid,nmsg=0;
    MESSAGE msg;
    mid=msgget(ftok(".",ID),IPC_CREAT|0666);
    msgctl(mid,IPC_RMID,NULL);
    mid=msgget(ftok(".",ID),IPC_CREAT|0666);
    while(1) {

        if (msgrcv(mid, &msg, sizeof(msg.buffer), SERVER, MSG_NOERROR)== -1) {
            printf("Server: msgrcv\n");
            return 2;
        } else nmsg++;

//        msg.msg_to = msg.msg_fm;
//        msg.msg_fm = SERVER;
//        printf("%s",msg.buffer);
        //Document Writer
        if(msg.buffer[0]=='/'&&msg.buffer[1]=='d')
        {
            msg.msg_to = WRITER;
            msg.msg_fm = EDITOR;
            printf("%s",msg.buffer);
            if (msgsnd(mid, &msg, sizeof(msg.buffer), 0) == -1) {
                printf("Server: msgsnd\n");
                return 3;
            } else nmsg--;
        }
        else{
            char newMsg[100],oldMsg[100];
            sprintf(oldMsg,"%d %s",nmsg,msg.buffer);
            printf("%s\n",oldMsg);

            printf("want to enter newReader PID (y/n): ");
            char res[2];
            scanf("%s",res);


            if(res[0]=='y'){
                char pd[10];
                printf("enter newsReader pid : ");
                scanf("%s",pd);
                sprintf(newMsg,"%s %s",pd,oldMsg);
                //strcpy(newMsg,pd);
                //strncat(newMsg,msg.buffer,100);
            } else{
                strcpy(newMsg,oldMsg);
            }

            printf("%s",newMsg);
            key_t key = ftok("shmfile",SHM_KEY);
            int shmid = shmget(key,1024,0666|IPC_CREAT);
            char *str = (char*) shmat(shmid,(void*)0,0);

            strcpy(str,newMsg);

            printf("Data written in memory: %s\n",str);

            shmdt(str);

        }

//        if (msgsnd(mid, &msg, sizeof(msg.buffer), 0) == -1) {
//            printf("Server: msgsnd\n");
//            return 3;
//        }
        sleep(5);

    }
    return 0;
}