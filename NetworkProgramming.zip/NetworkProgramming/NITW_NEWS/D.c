#include "local.h"
#include "header.h"

int main() {
    int mid, n;
    MESSAGE msg;

    mid = msgget(ftok(".", ID), 0666);

    while (1)
    {
        if (msgrcv(mid, &msg, sizeof(msg.buffer), WRITER, MSG_NOERROR) != -1) {
            int fd = open("file.txt", O_WRONLY|O_APPEND);
            write(fd, msg.buffer, strlen(msg.buffer));
            close(fd);
        }
        else{
            printf("Server: msgrcv\n");
            return 2;
        }
        sleep(3);
    }

    return 0;
}