#include "header.h"

int main()
{
    while(1)
    {
        char a[] = "Hello P1\n";
        write(1, a, strlen(a) + 1);
        fflush(stdout);
        sleep(5 + rand() % 5);
    }
    return 0;
}
