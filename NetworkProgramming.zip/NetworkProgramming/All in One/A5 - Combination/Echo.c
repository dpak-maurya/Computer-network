#include "header.h"

int main(int argv,char* argc[])
{
	int fd = open(argc[1],O_RDWR | O_CREAT);
	char a[101];
	
    while(1)
    {
        printf("Enter text to echo to client - ");
        scanf("%s",a);

		if(a[0] == '.') 
		{
			key_t key = ftok(argc[1],65); 
			int shmid = shmget(key,1,0666|IPC_CREAT); 
			int* x = (int*) shmat(shmid,(void*)0,0);
			*x = 1;
			shmdt(x);
			
			printf("Echo terminating\n");
			
			break;
		}
        
        write(fd, a, 100);
        fflush(stdout);
    }
    	
    return 0;
}
