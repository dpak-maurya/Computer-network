#include "header.h"

int main()
{
	char a[100];
	char pid[50];

	mkfifo("ffifo",0666);
	
	int pp = getpid();
	sprintf(pid,"%d",pp);
	mkfifo(pid,0666);
	
	char name[50];
	printf("Enter user name - ");
	scanf("%s",name);
	
	char con[100];
	sprintf(con,"0 %s %s",pid,name);
	
	int ffd = open("ffifo",O_WRONLY);
	write(ffd,con,100);
	close(ffd);
	
	struct pollfd fds[2];
    fds[0].events = fds[1].events = POLLIN;
    fds[0].fd = open(pid, O_RDONLY | O_NONBLOCK);
    fds[1].fd = STDIN_FILENO;

    while(1)
    {
        int ret = poll(fds, 2, 500);

        if(!ret) continue;

        if(fds[0].revents & POLLIN)
        {
            char inp[101];
            read(fds[0].fd, inp, 100);
            printf("%s\n", inp);
        }

        if(fds[1].revents & POLLIN)
        {
            char inp[100], msg[100];
            inp[0] = '\0';
            fgets(inp, 100, stdin);
            inp[strlen(inp) - 1] = '\0';
			
            sprintf(msg,"1 %s %s",pid,inp);
            
            int wrfd = open("ffifo", O_WRONLY);
            write(wrfd, msg, strlen(msg) + 1);
            close(wrfd);
        }
    }

    return 0;
		
} 
