#include "header.h"

char fifos[100][100];
char names[100][100];
int tot = 0;
int *x;

void hdfn(int sno)
{
    int i = 0;
    for(i = 0; i < tot; i++)
    {
    	key_t key = ftok(fifos[i],65); 
    	int shmid = shmget(key,1,0666|IPC_CREAT); 
    	x = (int*) shmat(shmid,(void*)0,0);
    	
    	if((*x) == 1)
    	{
    		*x = 0;
    		shmdt(x);
    		break;
    	}
    	shmdt(x);
    }
    
    if(i == tot)
    {
    	printf("No available clients\n");
    	return;
    }

    char inp[100];
    snprintf(inp, 100, "%s has been echoed\n", names[i]);
    
    for(int j = 0; j < tot; j++)
    {
        key_t key = ftok(fifos[j],65); 
    	int shmid = shmget(key,1,0666|IPC_CREAT); 
    	x = (int*) shmat(shmid,(void*)0,0);
   		
        if((*x))
        {
            int fd = open(fifos[j], O_WRONLY);
            write(fd, inp, strlen(inp) + 1);
            close(fd);
        }
        
        shmdt(x);
    }

	char ech[100];
	snprintf(ech,100,"gnome-terminal -- \"./Echo\" %s",fifos[i]);
    system(ech);
}

int main()
{
    signal(SIGUSR1, hdfn);
    mkfifo("p2fifo", 0666);
   	mkfifo("ffifo", 0666);
    int pp[2];
    pipe(pp);
    
    if(fork())
        close(pp[1]);
    else
    {
        close(pp[0]);
        dup2(pp[1], 1);
        char *args[] = {NULL};
        execvp("./P1", args);
    }
    
    if(!fork())
    {
        int fd = open("p2fifo", O_WRONLY);
        dup2(fd, 1);
        char *args[] = {NULL};
        execvp("./P2", args);
    }
    
    if(!fork())
    {
        char *args[] = {NULL};
        execvp("./P4", args);
    }
    
    FILE *fp = popen("./P3", "r");
    FILE * fp5 = popen("./P5", "w");
    
    printf("Server started\n");
    dup2(fileno(fp5), 1);
    char inp[101];
    
    int len = 0, fd;

    struct pollfd fds[5];
    fds[0].fd = open("ffifo", O_RDONLY | O_NONBLOCK);
    fds[0].events = POLLIN;
    fds[1].fd = pp[0];
    fds[1].events = POLLIN;
    fds[2].fd = open("p2fifo", O_RDONLY, O_NONBLOCK);
    fds[2].events = POLLIN;
    fds[3].fd = fileno(fp);
    fds[3].events = POLLIN;
    fds[4].fd = 0;
    fds[4].events = POLLIN;

	while(1)
    {
		inp[0] = 0;
        poll(fds, 5, -1);
        
        //From Pipe (P1)
        if(fds[1].revents & POLLIN)
        {
            inp[0] = 0;
            len = read(fds[1].fd, inp, 100);
            for(int i = 0; i < tot; i++)
            {
            	key_t key = ftok(fifos[i],65); 
    			int shmid = shmget(key,1,0666|IPC_CREAT); 
    			x = (int*) shmat(shmid,(void*)0,0);
    			
                if((*x))
                {
                    fd = open(fifos[i], O_WRONLY);
                    write(fd, inp, strlen(inp) + 1);
                    close(fd);
                }
                
                shmdt(x);
            }
            write(1, inp, strlen(inp) + 1);
            fflush(stdout);
        }
        
        //From FIFO (P2)
        if(fds[2].revents & POLLIN)
        {
            inp[0] = 0;
            len = read(fds[2].fd, inp, 100);
            for(int i = 0; i < tot; i++)
            {
                key_t key = ftok(fifos[i],65); 
    			int shmid = shmget(key,1,0666|IPC_CREAT); 
    			x = (int*) shmat(shmid,(void*)0,0);
    			
                if((*x))
                {
                    fd = open(fifos[i], O_WRONLY);
                    write(fd, inp, strlen(inp) + 1);
                    close(fd);
                }
                
                shmdt(x);
            }
            write(1, inp, strlen(inp) + 1);
            fflush(stdout);
        }
        
        //From P3
        if(fds[3].revents & POLLIN)
        {
            inp[0] = 0;
            len = read(fds[3].fd, inp, 100);
            for(int i = 0; i < tot; i++)
            {
                key_t key = ftok(fifos[i],65); 
    			int shmid = shmget(key,1,0666|IPC_CREAT); 
    			x = (int*) shmat(shmid,(void*)0,0);
    			
                if((*x))
                {
                    fd = open(fifos[i], O_WRONLY);
                    write(fd, inp, strlen(inp) + 1);
                    close(fd);
                }
                
                shmdt(x);
            }
            write(1, inp, strlen(inp) + 1);
            fflush(stdout);
        }
        
        //From STDinput
        if(fds[4].revents & POLLIN)
        {
            inp[0] = 0;
            fgets(inp, 100, stdin);
            inp[strlen(inp) - 1] = '\0';
            
            char mes[101];
            snprintf(mes, 100, "Server: %s", inp);

            for(int i = 0; i < tot; i++)
            {
                key_t key = ftok(fifos[i],65); 
    			int shmid = shmget(key,1,0666|IPC_CREAT); 
    			x = (int*) shmat(shmid,(void*)0,0);
    			
                if((*x))
                {
                    fd = open(fifos[i], O_WRONLY);
                    write(fd, mes, strlen(mes) + 1);
                    close(fd);
                }
                
                shmdt(x);
            }
            write(1, inp, strlen(inp) + 1);
            fflush(stdout);
        }
        
        //From clients to Famous FIFO
        if(fds[0].revents & POLLIN)
        {
            char a[100];
            len = read(fds[0].fd, a, 100);
         
         	char pid[50];
			char msg[100];
			char name[100];
			
			int pt = 2;
			
			//separating the pid from input message - "0/1/2 PID MSG"
			while(pt <= strlen(a))
			{
				if(a[pt] == ' ')
				{
					pid[pt - 2] = '\0';
					break;
				}
				
				pid[pt - 2] = a[pt];
				pt++;
			}
			
			//separating text(MSG) from input message - "0/1/2 PID MSG"
			int mi = 0;
			while(pt <= strlen(a))
			{
				msg[mi] = a[pt];
				if(a[pt] == '\0') break;
				pt++;
				mi++;
			}
			
			for(int i=0;i<tot;i++)
			{
				if(strcmp(fifos[i],pid) == 0) strcpy(name,names[i]);
			}
			
			printf("PID - %s\n",pid);
			printf("Message - %s\n",msg);
			printf("Name - %s\n",name);
			
			//Connect
			if(a[0] == '0')
			{
		//		printf("If\n");
				strcpy(fifos[tot],pid);
				strcpy(names[tot],msg);
				tot++;
				
				mkfifo(pid,0666);
				
				key_t key = ftok(pid,65); 
    			int shmid = shmget(key,1,0666|IPC_CREAT); 
    			x = (int*) shmat(shmid,(void*)0,0);
    			*x = 1;
                shmdt(x);
			}
			
			//Message
			else if(a[0] == '1')
			{
			//	printf("Else if\n");
				char print[100];
				sprintf(print,"%s - %s",name,msg);
				
				printf("%s\n",print);
				
				for(int i=0;i<tot;i++)
				{
				//	printf("i - %d\n",i);
				//	printf("pid - %s\n",pid);
				//	printf("pids[i] - %s\n",pids[i]);
					
					if(strcmp(fifos[i],pid) == 0) continue;
					
					int wfd = open(fifos[i],O_RDWR | O_CREAT);
					if(wfd == -1) printf("Unable to open\n");
					write(wfd,print,100);
					close(wfd);
				}
			}
			
			//Disconnect
			else
			{
			//	printf("Else\n");
				
				tot--;
				
				for(int i=0;i<tot;i++)
				{
					if(strcmp(fifos[i],pid) == 0)
					{
						for(int j=i;j<tot;j++)
						{
							strcpy(fifos[j],fifos[j+1]);
							strcpy(names[j],names[j+1]);
						}
						break;
					}
				}
			}           
        }
    }
    return 0;
}
