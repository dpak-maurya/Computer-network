//
// Created by dpak on 07/01/20.
//

#ifndef ALL_IN_ONE_HEADER_H
#define ALL_IN_ONE_HEADER_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/poll.h>
#include <signal.h>

#endif //ALL_IN_ONE_HEADER_H
