#include "header.h"

int main()
{
	char b[100];

	while(read(0,b,20) > 0)
	{
		printf("(P5) - %s\n",b);
	}
	
	return 0;
} 




