#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<netdb.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<pthread.h>
#define PORT 8001
#define SA struct sockaddr
int sfd;
void * read_func()
{
	while(1)
	{
		char buffer[80];
		read(sfd,buffer,sizeof(buffer));
		printf("Message : %s\n",buffer);
	}
}
void * write_func()
{
	while(1)
	{
		char buffer[80];
		fgets(buffer,80,stdin);
		write(sfd,buffer,sizeof(buffer));
	}
}
int main()
{
	struct sockaddr_in serveraddr, clientaddr;
	sfd = socket(AF_INET, SOCK_STREAM, 0);
	bzero(&serveraddr, sizeof(serveraddr));
	
	serveraddr.sin_family=AF_INET;
	serveraddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	
	serveraddr.sin_port=htons(PORT);

	if(connect(sfd,(SA*)&serveraddr, sizeof(serveraddr))==0)
		printf("Connected to server\n");
	else
		printf("Not connected to server\n");

	pthread_t t1,t2;
	pthread_create(&t1,NULL,write_func,NULL);
	pthread_create(&t2,NULL,read_func,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	
	close(sfd);
}


