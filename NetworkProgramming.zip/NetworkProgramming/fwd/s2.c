#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
int main()
{
	while(1)
	{
		char s[80];
		read(0,s,80);
		for (int i=0;s[i]!='\0';i++)
		{
			if(s[i]>='A' && s[i]<='Z')
				s[i]=s[i]+32;
		}
		write(1,s,sizeof(s));
	}
}
