#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netdb.h>
#include<sys/types.h>
#include<sys/select.h>
#define SA struct sockaddr
#define PORT1 8001
#define PORT2 8002
int max(int x,int y)
{
	if(x>y)
		return x;
	else
		return y;
}
int main()
{
	int sfd1,sfd2;
	sfd1=socket(AF_INET,SOCK_STREAM,0);
	sfd2=socket(AF_INET,SOCK_STREAM,0);
	
	struct sockaddr_in servaddr1,servaddr2,clientaddr;
	
	servaddr1.sin_family=AF_INET;
	servaddr1.sin_addr.s_addr=htonl(INADDR_ANY);
	servaddr1.sin_port=htons(PORT1);
	
	servaddr2.sin_family=AF_INET;
	servaddr2.sin_addr.s_addr=htonl(INADDR_ANY);
	servaddr2.sin_port=htons(PORT2);
	
	if(bind(sfd1,(SA*)&servaddr1,sizeof(servaddr1))==0)
		printf("Binding 1 successful \n");
	else
		printf("Bindng 1 Failed\n");
		
	if(bind(sfd2,(SA*)&servaddr2,sizeof(servaddr2))==0)
		printf("Binding 2 successful \n");
	else
		printf("Bindng 2 Failed\n");
	
	if(listen(sfd1,5)==0)
		printf("Server port 1 is listening\n");
	if(listen(sfd2,5)==0)
		printf("Server port 2 is listening\n");
	
	fd_set rfds;
	FD_ZERO(&rfds);
	int maxfd=max(sfd1,sfd2)+1;
	while(1)
	{
		FD_SET(sfd1,&rfds);
		FD_SET(sfd2,&rfds);
		int ready=select(maxfd,&rfds,NULL,NULL,NULL);
		
		if(FD_ISSET(sfd1,&rfds))
		{
			int len=sizeof(clientaddr);
			int nsfd=accept(sfd1,(SA*)&clientaddr,&len);
			printf("Client is accepted at port 8001\n");
			int c=fork();
			if(c>0)
			{
				close(nsfd);
			}
			else
			{
				close(sfd1);
				dup2(nsfd,0);
				dup2(nsfd,1);
				char *argv[]={"./s1",NULL};
				execv(argv[0],argv);
			}
		}
		if(FD_ISSET(sfd2,&rfds))
		{
			int len=sizeof(clientaddr);
			int nsfd=accept(sfd2,(SA*)&clientaddr,&len);
			printf("Client is accepted at port 8002\n");
			int c=fork();
			if(c>0)
			{
				close(nsfd);
			}
			else
			{
				close(sfd2);
				dup2(nsfd,0);
				dup2(nsfd,1);
				char *argv[]={"./s2",NULL};
				execv(argv[0],argv);
			}
		}
	}
	
	
}
