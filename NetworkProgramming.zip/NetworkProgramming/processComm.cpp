#include "header.h"
#include<iostream>
using namespace std;
int main()
{
   int pp1[2],pp2[2];
   pipe(pp1);
   pipe(pp2);
   int c=fork();
   int fd;
   if(c>0){
   			close(pp1[0]);
   			close(pp2[1]);
   			cout<<"this is before dup2\n";
   			dup2(pp1[1],1);
   			cout<<"this is the parent process";
   			exit(1);
   			
   			//wait(NULL);
   		}	
   			
   			
   else{
   			close(pp1[1]);
   			close(pp2[0]);
   			cout<<"this is the child process\n";
   		     char buff[100];
   			read(pp1[0],buff,100);
   			cout<<buff<<" "<<strlen(buff)<<endl;
   			//dup2(pp1[0],1);
   			cout<<"this is after dup2\n";
   		}
   		return 0;
  }
  
   			
