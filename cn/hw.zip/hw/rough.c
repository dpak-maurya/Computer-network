#include "header.h"
int main()
{
	exec();
	char buff[100]=0;buff[0]='\0';
	read(0,buff,sizeof(buff));
	write(1,buff,strlen(buff));
	return 0;
}
