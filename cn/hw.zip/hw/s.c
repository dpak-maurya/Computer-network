#include"header.h"
struct dictionary
{
	char s[10];
	int fd;
	int here;
};
struct dictionary d[100];
int i;
void hdfn(int signo)
{
	for(int j=0;j<i;j++)
	{
		if(d[j].here==1)
		{
			d[j].here=0;
			close(d[j].fd);
			char statement[72]="";
			strcat(statement,"gnome-terminal -- /bin/bash -c './echon ");
			strcat(statement,d[i].s);
			strcat(statement,";'");
			system(statement);
		}
	}
}

int main()
{
	i=0;
	int f0=dup(0);int f1=dup(1);
	int pfd[2];
	pipe(pfd);
	int c=fork();
	if(c==0)
	{//child
		/*p1*/
		close(pfd[0]);
		while(1)
		{
			char Bff[]="Input from process1 :\n";
			write(pfd[1],Bff,strlen(Bff));
			for(int j=0;j<0x2fffffff;j++)
			;
		}
		exit(0);
	}
	//parent
	/*p2*/
	write(1,"done1",5);
	mkfifo("fifo",0666);
	int ffd=open("fifo",O_RDONLY);
	write(1,"done2",5);
	/*p3*/
	int fd=fileno(popen("./p3","r"));
	write(1,"done3",5);
	/*p4*/
	signal(SIGUSR1,hdfn);
	char statement[72]="";
	strcat(statement,"gnome-terminal -- /bin/bash -c './p4 ");
	char temp[10]="";
	sprintf(temp,"%d",(int)getpid());
	strcat(statement,temp);
	strcat(statement,";'");
	system(statement);
	write(1,"done4",5);
	/*p5*/
	int pout=fileno(popen("./p5.out","w"));
	write(f1,"done5",5);
	//sfd
	//mkfifo("ffifo",0666);
	int sfd=open("c.txt",O_RDONLY);
	write(f1,"start\n",6);
	c=fork();
	if(c==0)
	{//child//client add remove
		while(1)
		{
			char buff;
			char str[10];str[0]='\0';
			int size;int which=0;
			while(size=read(sfd,&buff,1))
			{
				if(size==0)
				continue;
				if(buff!='\n')
				{if(str[0]=='\0' && buff=='#'){which=0;}
				else if(str[0]=='\0' && buff=='X'){which=1;}
				else{strncat(str,&buff,1);}}
				else
				{
					if(which==0)
					{
						d[i].s[0]='\0';
						strcpy(d[i].s,str);//#pid
						mkfifo(d[i].s,0666);
						d[i].fd=open(d[i].s,O_WRONLY);
						d[i].here=1;
						str[0]='\0';
						i++;
					}
					else if(which=1)
					{
						for(int j=0;j<i;j++)
						{
							if(strcmp(d[j].s,str)==0)
							{
								d[i].fd=open(d[i].s,O_WRONLY);
								d[i].here=1;
								break;
							}						
						}
						str[0]='\0';
					}
				}
			}
		}
		return 0;
	}
	//gets input from 0,p1,p2,p3
	//input and output
	struct pollfd pofd[4];
	pofd[0].fd=f0/*0*/;pofd[1].fd=pfd[0];/*p1*/
	pofd[2].fd=ffd/*p2*/;pofd[3].fd=fd;/*p3*/
	pofd[0].events=pofd[1].events=pofd[2].events=pofd[3].events=0;
	pofd[0].events|=POLLIN;pofd[1].events|=POLLIN;
	pofd[2].events|=POLLIN;pofd[3].events|=POLLIN;
	int timeout=5000;
	while(1)
	{
		int ret=poll(pofd,4,timeout);
		write(f1,"first",5);
		if(ret==0)
		write(1,"timeout\n",strlen("timeout")+1);
		else if(ret>0)
		{
			char buff[100];buff[0]='\0';
			for(int k=0;k<4;k++)
			{
				if(pofd[k].revents & POLLIN)
				{
					int siz=read(pofd[k].fd,buff,sizeof(buff));
					for(int j=0;j<=i;j++)
					{
						if(d[j].here)
							write(d[j].fd,buff,siz);
					}
					write(1,buff,siz);
					pofd[k].revents=0;
				}
			}
		}
	}
	return 0;
}
