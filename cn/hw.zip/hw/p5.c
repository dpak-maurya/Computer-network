#include "header.h"
int main()
{
	int n;
	char buff[100];buff[0]='\0';
	while(n=read(0,buff,sizeof(buff)))
	{
		if(n!=0)
		{
			write(1,buff,n);
			buff[0]='\0';
		}
	}
	return 0;
}
