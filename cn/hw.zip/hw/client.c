#include "header.h"
int main()
{
	//mkfifo("ffifo",0666);
	int sfd=open("c.txt",O_WRONLY|O_APPEND);
	char me='#';write(sfd,&me,1);
	char buff[10];buff[0]='\0';
	sprintf(buff,"%d",(int)getpid());
	write(sfd,buff,strlen(buff));
	write(1,buff,strlen(buff)+1);
	buff[0]='\n';
	write(sfd,buff,1);
	write(1,buff,1);
	close(sfd);
	buff[0]='\0';
	sprintf(buff,"%d",(int)getpid());
	while(1)
	{
		mkfifo(buff,0666);
		int nsfd=open(buff,O_RDONLY);
		buff[0]='\0';
		int n;
		while(n=read(nsfd,buff,sizeof(buff)))
		{
			if(n!=0)
			{
				write(1,buff,n);
				buff[0]='\0';
			}
		}
	}
	return 0;
}
