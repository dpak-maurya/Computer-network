#include"header.h"
int main()
{
	while(1)
	{
		for(int j=0;j<0x2fffffff;j++)
		;
		printf("Input from process3\n");
	}
	return 0;
}

